jQuery(function ($) {
	"use strict";

});