<?php
/**
 * Plugin Name: CPT dmzTheme
 */

//Инициализируем новый тип сообщений
	function dmz_init_post_types() 
	{
		if ( function_exists( 'dmz_get_post_types' ) ):

			foreach ( dmz_get_post_types() as $type => $options ) 
			{
				dmz_add_post_type( $type, $options['config'], $options['singular'], $options['multiple'] );
			}

		endif;
	}
	add_action('init', 'dmz_init_post_types');


//Регистрируем новый тип сообщений
	function dmz_add_post_type( $name, $config, $singular = 'Entry', $multiple = 'Entries' ) 
	{
		if ( !isset( $config['labels'] ) ):

			$config['labels'] = [

				'name' => $multiple,
				'singular_name' => $singular,
			];

		endif;

		register_post_type( $name, $config );
	}

//Инициализируем новую таксономию
	function dmz_init_taxonomies() 
	{
		if ( function_exists( 'dmz_get_taxonomies' ) ):

			foreach ( dmz_get_taxonomies() as $type => $options ) 
			{
				dmz_add_taxonomy( $type, $options['for'], $options['config'], $options['singular'], $options['multiple'] );
			}
			
		endif;
	}
	add_action('init', 'dmz_init_taxonomies');



//регистрируем новую таксономию
	function dmz_add_taxonomy( $name, $object_type, $config, $singular = 'Entry', $multiple = 'Entries' ) 
	{
		if ( !isset($config['labels'] ) ):

			$config['labels'] = [

				'name' => $multiple,
				'singular_name' => $singular,
			];

		endif;

		register_taxonomy( $name, $object_type, $config );
	}

//Подключаем темплэйт с функцией dmz_get_post_types()
	require_once ( get_template_directory() . '/dmz_theme/dmz-custom-post-types.php' );